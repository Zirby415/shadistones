Hey :)

Basic controls can be found in emulators setup

gl, I hope you enjoy this lil' hack I made :D